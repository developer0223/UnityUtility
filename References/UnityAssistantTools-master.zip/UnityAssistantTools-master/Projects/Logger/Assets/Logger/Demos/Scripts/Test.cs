﻿namespace developer0223
{
    using UnityEngine;

    using developer0223.Logger;

    public class Test : MonoBehaviour
    {
        private void Start()
        {
            Log.Write("Hello World");
        }
    }
}