# FPSDisplayer
Tool to display fps at GUI in Unity Engine.

> [See Details & How to Use](https://github.com/JungukHom/UnityAssistantTool/blob/master/FPSDisplayer.md "Detail of FPSDisplayer")


</br></br>


# Logger
Tool to log with .txt file.

> [See Details & How to Use](https://github.com/JungukHom/UnityAssistantTool/blob/master/Logger.md "Detail of Logger")
