namespace developer0223.CameraShaker
{
    public enum Type
    {
        Linear,
        Acceleration,
        Deceleration,
        EarthQuake
    }
}