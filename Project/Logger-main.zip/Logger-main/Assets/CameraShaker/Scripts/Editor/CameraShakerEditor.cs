namespace developer0223.CameraShaker
{
    // System
    using System;
    using System.Collections;
    using System.Collections.Generic;

    // Unity
    using UnityEditor;
    using UnityEngine;
    using UnityEngine.UI;

    // Project
    // Alias

    [CanEditMultipleObjects]
    [CustomEditor(typeof(CameraShaker))]
    public class CameraShakerConfigEditor : Editor
    {
        protected SerializedProperty type = null;

        // Common Variables
        protected SerializedProperty delayTime = null;
        protected SerializedProperty duration = null;

        // Linear
        //protected SerializedProperty moveSpeed = null;
        protected SerializedProperty destination = null;

        // Acceleration
        protected SerializedProperty accelAmount = null;
        // Deceleration
        //protected SerializedProperty accelCurve = null;

        // Teleport
        protected SerializedProperty randomSeed = null;
        protected SerializedProperty shakeAmount = null;
        protected SerializedProperty decreaseShakeAmount = null;

        // TODO : Temp variables
        private bool enable_helpboxMessage_decreaseShakeAmount = true;

        protected void OnEnable()
        {
            // Common
            type = serializedObject.FindProperty("type");
            delayTime = serializedObject.FindProperty("delayTime");
            duration = serializedObject.FindProperty("duration");

            // Linear
            //moveSpeed = serializedObject.FindProperty("moveSpeed");
            destination = serializedObject.FindProperty("destination");

            // Acceleration
            accelAmount = serializedObject.FindProperty("accelAmount");
            // Deceleration
            //accelCurve = serializedObject.FindProperty("accelCurve");

            // Teleport
            randomSeed = serializedObject.FindProperty("randomSeed");
            shakeAmount = serializedObject.FindProperty("shakeAmount");
            decreaseShakeAmount = serializedObject.FindProperty("decreaseShakeAmount");
        }

        public override void OnInspectorGUI()
        {
            base.OnInspectorGUI();

            EditorGUILayout.Space();
            EditorGUILayout.Space();

            EditorGUI.indentLevel += 1;

            // Common Fields
            EditorGUILayout.LabelField("Setting Fields", EditorStyles.boldLabel);
            EditorGUILayout.PropertyField(delayTime);

            switch (type.enumValueIndex)
            {
                case (int)Type.Linear:
                    //EditorGUILayout.PropertyField(moveSpeed);
                    EditorGUILayout.PropertyField(duration);
                    EditorGUILayout.PropertyField(destination);
                    break;

                case (int)Type.Acceleration:
                case (int)Type.Deceleration:
                    EditorGUILayout.PropertyField(accelAmount);
                    EditorGUILayout.PropertyField(destination);
                    //EditorGUILayout.PropertyField(accelCurve);
                    break;


                case (int)Type.EarthQuake:
                    EditorGUILayout.PropertyField(duration);
                    EditorGUILayout.PropertyField(randomSeed);
                    EditorGUILayout.PropertyField(shakeAmount);
                    EditorGUILayout.PropertyField(decreaseShakeAmount);
                    break;

                default:
                    throw new Exception("Exception On CameraShakerEditor. (There is no selected type.)");
            }
            EditorGUI.indentLevel -= 1;

            // show help box
            if (decreaseShakeAmount.boolValue == false && enable_helpboxMessage_decreaseShakeAmount)
            {
                EditorGUILayout.HelpBox("EarthQuake.decreaseShakeAmount option is disabled. It may look unnatural. Press button below if you don't want to see this message.", MessageType.Warning);
                if (GUILayout.Button("Don't show this message again"))
                {
                    enable_helpboxMessage_decreaseShakeAmount = false;
                }
            }

            EditorGUILayout.Space();
            EditorGUILayout.Space();
            EditorGUILayout.LabelField("Control", EditorStyles.boldLabel);

            CameraShaker cameraShaker = (CameraShaker)target;
            if (GUILayout.Button("Start Shake"))
                cameraShaker.ShakeInEditorMode();

            if (GUILayout.Button("Stop Shake"))
                cameraShaker.StopShake();

            if (GUILayout.Button("Reset Position Only"))
                cameraShaker.ResetPosition();

            EditorGUILayout.Space();
            EditorGUILayout.Space();

            serializedObject.ApplyModifiedProperties();
        }
    }
}