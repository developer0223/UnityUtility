namespace developer0223.CameraShaker
{
    // System
    using System;
    using System.Collections;
    using System.Collections.Generic;

    // Unity
    using UnityEngine;
    using UnityEngine.UI;
    using Unity.EditorCoroutines.Editor;

    // Project
    // Alais

    [ExecuteInEditMode]
    [DisallowMultipleComponent]
    [AddComponentMenu("CameraShaker/CameraShaker")]
    public class CameraShaker : MonoBehaviour
    {
        // Type Variables
        [SerializeField]
        [Header("Camera Move Type")]
        public Type type = Type.Linear;

        // Common Variables
        // TODO : Return and SmoothReturn �߰� ����
        //[SerializeField]
        //[HideInInspector]
        //protected bool returnToDefaultPosition = true;

        //[SerializeField]
        //[HideInInspector]
        //protected bool moveSmoothWhileReturn = true;

        [SerializeField]
        [HideInInspector]
        protected float delayTime = 0.0f;

        [SerializeField]
        [HideInInspector]
        protected float duration = 1.0f;

        // Linear
        //[SerializeField]
        //[HideInInspector]
        //protected float moveSpeed = 1.0f;

        // TODO : �׷��� �������� ���� ����
        [SerializeField]
        [HideInInspector]
        protected Vector2 destination = Vector2.right;

        // Acceleration
        [Range(1.0f, 5.0f)]
        [SerializeField]
        [HideInInspector]
        protected float accelAmount = 1;

        // Deceleration

        // TODO : �׷��� �߰� ����
        //[SerializeField]
        //[HideInInspector]
        //protected AnimationCurve accelCurve = null;

        // EarthQuake
        [SerializeField]
        [HideInInspector]
        [ContextMenuItem("Random Value", "SetRandomSeed")]
        protected int randomSeed = 0;

        [Range(0.1f, 0.5f)]
        [SerializeField]
        [HideInInspector]
        protected float shakeAmount = 1.0f;

        [SerializeField]
        [HideInInspector]
        protected bool decreaseShakeAmount = true;

        [Header("Target Camera")]
        public Camera targetCamera = null;

        // private cached components
        private WaitForSeconds _wfs = null;

        private void Awake()
        {
            Initialize();
            Shake();
        }

        private void Initialize()
        {
            if (targetCamera == null)
            {
                if (Camera.main != null)
                    targetCamera = Camera.main;
                else
                    Debug.LogWarning("Cannot find target camera. Please register target camera into script. (CameraShaker.cs)");
            }

            // TODO : Camera �θ� ���� ���� �� �ڵ� ���� �ʿ�
            //if (targetCamera != null)
            //{

            //}
        }

        private EditorCoroutine currentCoroutine = null;
        public void ShakeInEditorMode(Action callback = null)
        {
            _wfs = new WaitForSeconds(delayTime);


            switch (type)
            {
                case Type.Linear:
                    currentCoroutine = EditorCoroutineUtility.StartCoroutine(Co_Linear(() => { callback?.Invoke(); }), this);
                    break;

                case Type.Acceleration:
                    currentCoroutine = EditorCoroutineUtility.StartCoroutine(Co_Acceleration(() => { callback?.Invoke(); }), this);
                    break;

                case Type.Deceleration:
                    currentCoroutine = EditorCoroutineUtility.StartCoroutine(Co_Deceleration(() => { callback?.Invoke(); }), this);
                    break;

                case Type.EarthQuake:
                    currentCoroutine = EditorCoroutineUtility.StartCoroutine(Co_EarthQuake(() => { callback?.Invoke(); }), this);
                    break;

                default:
                    currentCoroutine = EditorCoroutineUtility.StartCoroutine(Co_Linear(() => { callback?.Invoke(); }), this);
                    break;
            }
        }

        public void Shake(Action callback = null)
        {
            _wfs = new WaitForSeconds(delayTime);

            switch (type)
            {
                case Type.Linear:
                    StartCoroutine(Co_Linear(() => { callback?.Invoke(); }));
                    break;

                case Type.Acceleration:
                    StartCoroutine(Co_Acceleration(() => { callback?.Invoke(); }));
                    break;

                case Type.Deceleration:
                    StartCoroutine(Co_Deceleration(() => { callback?.Invoke(); }));
                    break;

                case Type.EarthQuake:
                    StartCoroutine(Co_EarthQuake(() => { callback?.Invoke(); }));
                    break;
            }
        }

        public void StopShake()
        {
            if (Application.isPlaying)
            {
                StopAllCoroutines();
                ResetPosition();
            }
            else
            {
                if (currentCoroutine != null)
                    EditorCoroutineUtility.StopCoroutine(currentCoroutine);
                ResetPosition();
            }
        }

        public void ResetPosition()
        {
            targetCamera.transform.localPosition = Vector3.zero;
        }

        [ContextMenu("Set Random Seed Value")]
        public void SetRandomSeed()
        {
            randomSeed = UnityEngine.Random.Range(0, int.MaxValue);
        }

        private IEnumerator Co_Linear(Action callback = null)
        {
            yield return _wfs;

            float start = 0;
            float end = 1;
            float current = start;

            while (current < end)
            {
                current += (Time.deltaTime / duration);
                Vector3 _position = Vector3.Lerp(Vector3.zero, destination, current);
                targetCamera.transform.localPosition = _position;

                yield return null;
            }

            callback.Invoke();
        }

        private IEnumerator Co_Acceleration(Action callback = null)
        {
            yield return _wfs;

            float start = 0;
            float end = 1;
            float current = start;

            while (current < end)
            {
                current += (Time.deltaTime / duration);
                current *= (1.0f + (accelAmount * 0.01f));
                current = Mathf.Clamp(current, 0.7f, 1.3f);
                Vector3 _position = Vector3.Lerp(Vector3.zero, destination, current);
                targetCamera.transform.localPosition = _position;

                yield return null;
            }

            callback.Invoke();
        }

        private IEnumerator Co_Deceleration(Action callback = null)
        {
            yield return _wfs;

            float start = 0;
            float end = 1;
            float current = start;

            while (current < end)
            {
                current += (Time.deltaTime / duration);
                current *= (1.0f - (accelAmount * 0.01f));
                current = Mathf.Clamp(current, 0.7f, 1.3f);
                Vector3 _position = Vector3.Lerp(Vector3.zero, destination, current);
                targetCamera.transform.localPosition = _position;

                yield return null;
            }

            callback.Invoke();
        }

        private IEnumerator Co_EarthQuake(Action callback = null)
        {
            yield return _wfs;

            Vector3 defaultPosition = Vector3.zero;
            //Vector3 defaultPosition = targetCamera.transform.localPosition;

            UnityEngine.Random.InitState(randomSeed);

            float _duration = duration;
            float _shakeAmount = shakeAmount;

            while (_duration > 0)
            {
                targetCamera.transform.localPosition = defaultPosition + UnityEngine.Random.insideUnitSphere * _shakeAmount;
                _duration -= Time.deltaTime;

                if (decreaseShakeAmount)
                    _shakeAmount *= 0.99f;

                yield return null;
            }

            targetCamera.transform.localPosition = defaultPosition;

            callback.Invoke();
        }
    }
}