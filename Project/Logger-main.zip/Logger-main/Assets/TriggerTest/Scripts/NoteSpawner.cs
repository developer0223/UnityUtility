// System
using System;
using System.Collections;
using System.Collections.Generic;

// Unity
using UnityEngine;
using UnityEngine.UI;

// Project
// Alais

public class NoteSpawner : MonoBehaviour
{
    public Vector3 defaultStartPosition = new Vector3(-7.5f, 0, 0);
    public Vector3 defaultEndPosition = new Vector3(+7.5f, 0, 0);
    public float defaultLifeDuration = 3.0f;

    private void Start()
    {
        StartCoroutine(Co_InstantiateNoteWithRandomDuration());
    }

    private IEnumerator Co_InstantiateNoteWithRandomDuration()
    {
        while (Application.isPlaying)
        {
            int spawnNoteCount = UnityEngine.Random.Range(1, 3);

            if (spawnNoteCount == 1)
            {
                Note.Create(defaultStartPosition, defaultEndPosition, defaultLifeDuration, true);
            }
            else // spawnNoteCount == 2
            {
                Note.Create(defaultStartPosition, defaultEndPosition, defaultLifeDuration, true);
                yield return new WaitForSeconds(0.1f);
                Note.Create(defaultStartPosition, defaultEndPosition, defaultLifeDuration, false);
            }

            yield return new WaitForSeconds(2f); // UnityEngine.Random.Range(0.5f, 1.0f)
        }
    }
}
