// System
using System;
using System.Collections;
using System.Collections.Generic;

// Unity
using UnityEngine;
using UnityEngine.UI;

// Project
// Alais

[RequireComponent(typeof(Rigidbody))]
[RequireComponent(typeof(BoxCollider))]
public class LastNoteChecker : MonoBehaviour
{
    public new Rigidbody rigidbody = null;
    public BoxCollider triggerBox = null;

    public List<GameObject> triggeredObjectList = null;

    private void Awake()
    {
        rigidbody = GetComponent<Rigidbody>();
        rigidbody.useGravity = false;

        if (triggerBox == null)
        {
            triggerBox = GetComponent<BoxCollider>();
            triggerBox.size = new Vector3(2, 1, 1);
            triggerBox.isTrigger = true;
        }

        triggeredObjectList = new List<GameObject>();
    }

    private void Update()
    {
        if (Input.GetKeyDown(KeyCode.Space))
        {
            CheckExistingObjects();
        }
    }

    private void CheckExistingObjects()
    {
        // TODO : ���⼭ ó���ϸ��.
        if (triggeredObjectList.Count == 1)
        {
            Destroy(triggeredObjectList[0].gameObject);
            triggeredObjectList.Clear();
        }
        //else
        //{
        //    Debug.Log($"Existing gameObject count is none or bigger than 2");
        //}
    }

    private void OnTriggerEnter(Collider other)
    {
        triggeredObjectList.Add(other.gameObject);
    }

    private void OnTriggerExit(Collider other)
    {
        triggeredObjectList.Remove(other.gameObject);
    }
}
