// System
using System;
using System.Collections;
using System.Collections.Generic;

// Unity
using UnityEngine;
using UnityEngine.UI;

// Project
// Alais

public class Note : MonoBehaviour
{
    private static readonly string PathA = "NoteA";
    private static readonly string PathB = "NoteB";

    public static Note Create(Vector3 startPosition, Vector3 endPosition, float duration, bool typeA)
    {
        GameObject _prefab = Resources.Load(typeA ? PathA : PathB) as GameObject;
        GameObject _gameObject = Instantiate(_prefab, startPosition, Quaternion.identity);
        Note _script = _gameObject.GetComponent<Note>();
        _script.InitializeWith(startPosition, endPosition, duration);

        return _script;
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////////

    public Vector3 startPosition = Vector3.left;
    public Vector3 endPosition = Vector3.right;
    public float duration = 1.0f;

    private void Start()
    {
        StartCoroutine(Co_MoveLinear());
    }

    public void InitializeWith(Vector3 startPosition, Vector3 endPosition, float duration)
    {
        this.startPosition = startPosition;
        this.endPosition = endPosition;
        this.duration = duration;
    }

    private IEnumerator Co_MoveLinear()
    {
        transform.position = startPosition;

        float start = 0;
        float end = 1;

        float current = start;

        while (current < end)
        {
            current += Time.deltaTime / duration;
            transform.position = Vector3.Lerp(startPosition, endPosition, current);
            yield return null;
        }

        yield return new WaitForSeconds(0.5f);
        Destroy(gameObject);
    }
}
