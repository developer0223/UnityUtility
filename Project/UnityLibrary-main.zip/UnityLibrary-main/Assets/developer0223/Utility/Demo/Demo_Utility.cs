// System
using System;
using System.Collections;
using System.Collections.Generic;

// Unity
using UnityEngine;
using UnityEngine.UI;

// Project
// Alias

public class Demo_Utility : MonoBehaviour
{
    private void Start()
    {
        UseMathUtility();
        UseInputHandler();
    }

    public void UseMathUtility()
    {
        Debug.Log(Utility.Abs(10)); // 10
        Debug.Log(Utility.Abs(-5)); // 5
        Debug.Log(Utility.Abs(-5.456f)); // 5.456
        Debug.Log(Utility.Abs(1.86f)); // 1.86

        int int_value = 15;
        float float_value = 163.25f;
        Debug.Log(Utility.Clamp(int_value, 0, 14)); // 14
        Debug.Log(Utility.Clamp(int_value, 3, 14)); // 14
        Debug.Log(Utility.Clamp(int_value, 0, 16)); // 15

        Debug.Log(Utility.Clamp(float_value, 100, 200)); // 163.25
        Debug.Log(Utility.Clamp(float_value, 200, 400)); // 200
        Debug.Log(Utility.Clamp(float_value, 0, 50)); // 50
    }

    public void UseInputHandler()
    {
        InputHandler.GetOrCreate().Add(KeyCode.Escape, () => { Debug.Log("ESC BUTTON PRESSED"); });
        InputHandler.GetOrCreate().Add(KeyCode.Escape, () => { Debug.Log("ESC BUTTON PRESSED 2"); }, true);
        InputHandler.GetOrCreate().Append(KeyCode.Escape, () => { Debug.Log("ESC BUTTON PRESSED 3"); }, true);
    }
}
