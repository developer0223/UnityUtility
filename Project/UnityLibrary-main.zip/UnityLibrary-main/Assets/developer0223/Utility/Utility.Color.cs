// System
using System;
using System.Collections;
using System.Collections.Generic;

// Unity
using UnityEngine;
using UnityEngine.UI;

// Project
// Alias

public partial class Utility
{
    private static float Max = 255;

    public static Color ToNormalizedColor(float r, float g, float b, float a = 255.0f)
    {
        r /= Max;
        g /= Max;
        b /= Max;
        a /= Max;

        return new Color(r, g, b, a);
    }
}
