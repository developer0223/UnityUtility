﻿// System
using System;
using System.Collections;
using System.Collections.Generic;

// Unity
using UnityEngine;

public class InputHandler : MonoBehaviour
{
    ////////// singleton ///////////////////////////////////////////////////////////////////////////////
    // private static class instance
    private static InputHandler _instance = null;

    // get class instance
    public static InputHandler GetOrCreate() => _instance ?? (_instance = new GameObject("InputHandler").AddComponent<InputHandler>());

    // private constructor
    private InputHandler() { }

    ////////////////////////////////////////////////////////////////////////////////////////////////////

    // key store dictionary
    private Dictionary<KeyCode, Action> targetKeyCodes = new Dictionary<KeyCode, Action>();

    private void Awake()
    {
        StartCoroutine(nameof(Co_Update));
    }

    private IEnumerator Co_Update()
    {
        while (true)
        {
            if (Input.anyKeyDown)
            {
                foreach (KeyValuePair<KeyCode, Action> keyValuePair in targetKeyCodes)
                {
                    if (Input.GetKeyDown(keyValuePair.Key))
                    {
                        keyValuePair.Value?.Invoke();
                    }
                }
            }

            yield return null;
        }
    }

    public bool Add(KeyCode key, Action callback, bool replace = false)
    {
        if (targetKeyCodes.ContainsKey(key))
        {
            if (replace)
            {
                targetKeyCodes.Remove(key);
                targetKeyCodes.Add(key, callback);
            }
            return false;
        }

        targetKeyCodes.Add(key, callback);

        return true;
    }

    public bool Append(KeyCode key, Action callback, bool createNew = true)
    {
        if (targetKeyCodes.ContainsKey(key))
        {
            targetKeyCodes[key] += callback;
            return true;
        }

        if (createNew)
        {
            targetKeyCodes.Add(key, callback);
            return true;
        }

        return false;
    }

    public bool Delete(KeyCode key)
    {
        if (targetKeyCodes.ContainsKey(key))
        {
            targetKeyCodes.Remove(key);
            return true;
        }

        return false;
    }
}