// System
using System;
using System.Collections;
using System.Collections.Generic;

// Unity
using UnityEngine;
using UnityEngine.UI;

// Project
// Alias

public class Demo_Logger : MonoBehaviour
{
    private static readonly float Interval = 1.0f;

    private WaitForSeconds wfs = null;

    private void Start()
    {
        wfs = new WaitForSeconds(Interval);

        // how to use logger
        HowToUserLogger();

        // Write log with interval
        StartCoroutine(LogWithInterval("Write Log", Interval));
    }

    private void HowToUserLogger()
    {
        Logger.Log("Test Log 01");
        Logger.Log("Test Log 02");
        Logger.Log("Test Log 03");
    }

    private IEnumerator LogWithInterval(string content, float interval)
    {
        while (true)
        {
            Logger.Log(content);
            yield return new WaitForSeconds(interval);
        }
    }
}
