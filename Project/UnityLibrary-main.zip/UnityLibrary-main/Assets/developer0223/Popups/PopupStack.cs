﻿namespace NeoSoft.Library.Popups
{
    // System
    using System;
    using System.Collections;
    using System.Collections.Generic;

    // Unity
    using UnityEngine;
    using UnityEngine.UI;

    public class PopupStack
    {
        ////////// singleton ///////////////////////////////////////////////////////////////////////////////
        // private static class instance
        private static PopupStack _instance = null;

        // get class instance
        public static PopupStack GetOrCreate() => _instance ?? (_instance = new PopupStack());

        // private constructor
        private PopupStack() { }

        ////////////////////////////////////////////////////////////////////////////////////////////////////

        private Stack<Popup> popupStack = new Stack<Popup>();

        public void NotifyClosed(Popup popup)
        {

        }
    }
}