﻿namespace NeoSoft.Library.Popups
{
    // System
    using System;
    using System.Collections;
    using System.Collections.Generic;

    // Unity
    using UnityEngine;
    using UnityEngine.UI;
    using UnityEngine.EventSystems;

    public abstract class Popup : MonoBehaviour, IDragHandler, IBeginDragHandler, IEndDragHandler
    {
        // popup settings
        // TODO : make this efficient
        public class PopupSettings
        {
            public static long id = -1;
            public static bool dragable = true;
            public static bool escAble = true;
            public static float screenX = Screen.width;
            public static float screenY = Screen.height;
        }

        // cached components
        private new RectTransform transform;

        // priavate variables
        private Vector2 positionAdjustVector = Vector2.zero;

        protected abstract void AdjustPopupSettings();

        protected void Awake()
        {
            Initialize();
        }

        private void Initialize()
        {
            CacheComponents();
            AdjustPopupSettings();
            RegisterToStack();
        }

        protected void CacheComponents()
        {
            transform = GetComponent<RectTransform>();
        }

        protected void RegisterToStack()
        {
            PopupStack popupStack = PopupStack.GetOrCreate();
        }

        public void OnBeginDrag(PointerEventData eventData)
        {
            positionAdjustVector = Input.mousePosition - transform.position;
        }

        public void OnDrag(PointerEventData eventData)
        {
            Vector2 mousePosition = Input.mousePosition;
            Vector2 destination = mousePosition - positionAdjustVector;

            transform.position = GetAdjustedPopupPosition(destination);
        }

        public void OnEndDrag(PointerEventData eventData)
        {
            // do nothing
        }

        private Vector2 GetAdjustedPopupPosition(Vector2 popupPosition)
        {
            float width = popupPosition.x;
            float height = popupPosition.y;

            width = Mathf.Clamp(width, (transform.sizeDelta.x * 0.5f), PopupSettings.screenX - (transform.sizeDelta.x * 0.5f));
            height = Mathf.Clamp(height, (transform.sizeDelta.y * 0.5f), PopupSettings.screenY - (transform.sizeDelta.y * 0.5f));

            return new Vector2(width, height);
        }
    }
}