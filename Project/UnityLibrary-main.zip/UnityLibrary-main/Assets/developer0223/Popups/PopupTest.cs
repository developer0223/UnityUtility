﻿namespace NeoSoft.Library.Popups
{
    // System
    using System;
    using System.Collections;
    using System.Collections.Generic;

    // Unity
    using UnityEngine;
    using UnityEngine.UI;

    public class PopupTest : Popup
    {
        protected override void AdjustPopupSettings()
        {
            // do nothing
        }
    }
}