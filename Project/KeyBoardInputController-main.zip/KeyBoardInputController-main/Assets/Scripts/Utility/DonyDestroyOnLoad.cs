﻿// Unity
using UnityEngine;

public class DonyDestroyOnLoad : MonoBehaviour
{
    private void Awake()
    {
        DontDestroyOnLoad(this);
    }
}