﻿// System
using System;
using System.Collections.Generic;

// Unity
using UnityEngine;
using UnityEngine.SceneManagement;

public class InputHandler : MonoBehaviour
{
    // public singleton instance
    public static InputHandler Controller = null;

    private List<KeyBoardAction> OnCommonStateAction = null;
    private List<KeyBoardAction> OnEscapeStateAction = null;

    private void Awake()
    {
        Controller = this;

        OnCommonStateAction = new List<KeyBoardAction>();
        OnEscapeStateAction = new List<KeyBoardAction>();

        SceneManager.sceneLoaded += ClearLocalSceneActions;
    }

    private void Update()
    {
        if (Input.anyKey)
        {
            List<KeyBoardAction> target = GameManager.Controller.isEscaped ? OnEscapeStateAction : OnCommonStateAction;
            foreach (KeyBoardAction data in target)
            {
                if (Input.GetKeyDown(data.keyCode))
                {
                    data.callback?.Invoke();
                }
            }
        }
    }

    public void SetOnPressedListener(KeyBoardAction action)
    {
        if (action.isEscaped)
        {
            if (ContainsKey(OnEscapeStateAction, action.keyCode))
                Get(OnEscapeStateAction, action.keyCode).callback += action.callback;
            else
                Add(OnEscapeStateAction, action);
        }
        else
        {
            if (ContainsKey(OnCommonStateAction, action.keyCode))
                Get(OnCommonStateAction, action.keyCode).callback += action.callback;
            else
                Add(OnCommonStateAction, action);
        }
    }

    public void SetOnPressedListener(KeyCode keyCode, Action callback, bool escaped, bool isLocalAction)
    {
        KeyBoardAction action = new KeyBoardAction(keyCode, callback, escaped, isLocalAction);

        if (escaped)
        {
            if (ContainsKey(OnEscapeStateAction, keyCode))
                Get(OnEscapeStateAction, keyCode).callback += callback;
            else
                Add(OnEscapeStateAction, action);
        }
        else
        {
            if (ContainsKey(OnCommonStateAction, keyCode))
                Get(OnCommonStateAction, keyCode).callback += callback;
            else
                Add(OnCommonStateAction, action);
        }
    }

    public void RemoveOnPressedListener(KeyBoardAction action)
    {
        if (action.isEscaped)
        {
            if (ContainsKey(OnEscapeStateAction, action.keyCode))
                Get(OnEscapeStateAction, action.keyCode).callback -= action.callback;
            else
                Remove(OnEscapeStateAction, action.keyCode, action.callback);
        }
        else
        {
            if (ContainsKey(OnCommonStateAction, action.keyCode))
                Get(OnCommonStateAction, action.keyCode).callback -= action.callback;
            else
                Remove(OnCommonStateAction, action.keyCode, action.callback);
        }
    }

    public void RemoveOnPressedListener(KeyCode keyCode, Action callback, bool escaped)
    {
        if (escaped)
        {
            if (ContainsKey(OnEscapeStateAction, keyCode))
                Get(OnEscapeStateAction, keyCode).callback -= callback;
            else
                Remove(OnEscapeStateAction, keyCode, callback);
        }
        else
        {
            if (ContainsKey(OnCommonStateAction, keyCode))
                Get(OnCommonStateAction, keyCode).callback -= callback;
            else
                Remove(OnCommonStateAction, keyCode, callback);
        }
    }

    public void ClearLocalSceneActions(Scene scene, LoadSceneMode mode)
    {
        for (int i = OnCommonStateAction.Count - 1; i >= 0; i--)
        {
            if (OnCommonStateAction[i].isLocal)
                OnCommonStateAction.RemoveAt(i);
        }

        for (int i = OnEscapeStateAction.Count - 1; i >= 0; i--)
        {
            if (OnEscapeStateAction[i].isLocal)
                OnEscapeStateAction.RemoveAt(i);
        }
    }

    private bool ContainsKey(List<KeyBoardAction> list, KeyCode targetKeyCode)
    {
        foreach (KeyBoardAction action in list)
        {
            if (action.keyCode == targetKeyCode)
                return true;
        }

        return false;
    }

    private KeyBoardAction Get(List<KeyBoardAction> list, KeyCode targetKeyCode)
    {
        if (ContainsKey(list, targetKeyCode))
        {
            foreach (KeyBoardAction action in list)
            {
                if (action.keyCode == targetKeyCode)
                    return action;
            }
        }

        return null;
    }

    private void Add(List<KeyBoardAction> list, KeyBoardAction action)
    {
        //if (ContainsKey(list, action.keyCode))
        //{
        //    foreach (KeyBoardAction existingAction in list)
        //    {
        //        if (existingAction.keyCode == action.keyCode)
        //        {
        //            existingAction.callback += action.callback;
        //        }
        //    }
        //}
        //else
        list.Add(action);
    }

    private void Remove(List<KeyBoardAction> list, KeyCode targetKeyCode, Action callback)
    {
        if (ContainsKey(list, targetKeyCode))
        {
            foreach (KeyBoardAction action in list)
            {
                if (action.keyCode == targetKeyCode)
                {
                    if (action.callback != null)
                        action.callback -= callback;

                    if (action.callback == null)
                        list.Remove(action);

                    break;
                }
            }
        }
    }
}
