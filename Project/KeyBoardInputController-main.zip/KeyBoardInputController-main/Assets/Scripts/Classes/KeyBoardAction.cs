﻿// System
using System;

// Unity
using UnityEngine;

public class KeyBoardAction
{
    public readonly KeyCode keyCode;
    public Action callback;
    public readonly bool isEscaped = false;
    public readonly bool isLocal = false;

    public KeyBoardAction(KeyCode keyCode, Action callback)
    {
        this.keyCode = keyCode;
        this.callback = callback;
    }

    public KeyBoardAction(KeyCode keyCode, Action callback, bool isEscaped, bool isLocal = false)
    {
        this.keyCode = keyCode;
        this.callback = callback;
        this.isEscaped = isEscaped;
        this.isLocal = isLocal;
    }
}