﻿// Unity
using UnityEngine;

public class Player : MonoBehaviour
{
    public int x;
    public int z;

    private void Start()
    {
        x = (int)Mathf.Round(transform.position.x);
        z = (int)Mathf.Round(transform.position.z);

        RegisterListeners();
    }

    private void OnDestroy()
    {
        UnRegisterListeners();
    }

    private void RegisterListeners()
    {
        InputHandler.Controller.SetOnPressedListener(KeyCode.UpArrow, () => OnDirectionArrowKeyPressed(Direction.Up), false, true);
        InputHandler.Controller.SetOnPressedListener(KeyCode.DownArrow, () => OnDirectionArrowKeyPressed(Direction.Down), false, true);
        InputHandler.Controller.SetOnPressedListener(KeyCode.LeftArrow, () => OnDirectionArrowKeyPressed(Direction.Left), false, true);
        InputHandler.Controller.SetOnPressedListener(KeyCode.RightArrow, () => OnDirectionArrowKeyPressed(Direction.Right), false, true);
        InputHandler.Controller.SetOnPressedListener(KeyCode.Space, () => Debug.Log("Player Space"), false, true);
    }

    private void UnRegisterListeners()
    {
        InputHandler.Controller.RemoveOnPressedListener(KeyCode.UpArrow, () => OnDirectionArrowKeyPressed(Direction.Up), false);
        InputHandler.Controller.RemoveOnPressedListener(KeyCode.DownArrow, () => OnDirectionArrowKeyPressed(Direction.Down), false);
        InputHandler.Controller.RemoveOnPressedListener(KeyCode.LeftArrow, () => OnDirectionArrowKeyPressed(Direction.Left), false);
        InputHandler.Controller.RemoveOnPressedListener(KeyCode.RightArrow, () => OnDirectionArrowKeyPressed(Direction.Right), false);
        InputHandler.Controller.RemoveOnPressedListener(KeyCode.Space, () => Debug.Log("Player Space"), false);
    }

    private void OnDirectionArrowKeyPressed(Direction direction)
    {
        switch (direction)
        {
            case Direction.Up:
                z += 1;
                break;

            case Direction.Down:
                z -= 1;
                break;

            case Direction.Left:
                x -= 1;
                break;

            case Direction.Right:
                x += 1;
                break;
        }

        transform.position = new Vector3(x, 0, z);
    }
}