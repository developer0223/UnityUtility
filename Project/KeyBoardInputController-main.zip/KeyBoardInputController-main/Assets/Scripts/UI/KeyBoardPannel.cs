﻿// Unity
using UnityEngine;

public class KeyBoardPannel : MonoBehaviour
{
    public KeyBoardButton btn_default;

    private void Start()
    {
        if (btn_default)
            btn_default.SetSelected(true);
    }
}