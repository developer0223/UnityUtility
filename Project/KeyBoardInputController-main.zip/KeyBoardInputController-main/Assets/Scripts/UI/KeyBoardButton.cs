﻿// Unity
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Events;

public class KeyBoardButton : MonoBehaviour
{
    [Header("KeyBoard Arrow Buttons")]
    public KeyBoardButton btn_up;
    public KeyBoardButton btn_down;
    public KeyBoardButton btn_left;
    public KeyBoardButton btn_right;

    [Header("Button Outline Image")]
    public Image img_outline;

    [Header("Button Content Text")]
    public Text txt_content;

    [Header("Public Variables")]
    public bool isSelected = false;
    public bool isEscapedUI = true;
    public bool isLocalUI = true;

    // public hidden variables
    [HideInInspector]
    public Button btn_local;

    // private variables
    private bool isListenerRegistered = false;

    private void Awake()
    {
        btn_local = GetComponent<Button>();
    }

    private void OnEnable()
    {
        if (isSelected && !isListenerRegistered)
            SetSelected(true);
    }

    private void OnDisable()
    {
        SetSelected(false);
    }

    private void RegisterListeners()
    {
        if (isListenerRegistered && InputHandler.Controller)
            return;

        InputHandler.Controller.SetOnPressedListener(KeyCode.UpArrow, () => OnDirectionArrowKeyPressed(Direction.Up), isEscapedUI, isLocalUI);
        InputHandler.Controller.SetOnPressedListener(KeyCode.DownArrow, () => OnDirectionArrowKeyPressed(Direction.Down), isEscapedUI, isLocalUI);
        InputHandler.Controller.SetOnPressedListener(KeyCode.LeftArrow, () => OnDirectionArrowKeyPressed(Direction.Left), isEscapedUI, isLocalUI);
        InputHandler.Controller.SetOnPressedListener(KeyCode.RightArrow, () => OnDirectionArrowKeyPressed(Direction.Right), isEscapedUI, isLocalUI);
        InputHandler.Controller.SetOnPressedListener(KeyCode.Space, OnSpaceBarKeyPressed, isEscapedUI, isLocalUI);
        isListenerRegistered = true;
    }

    private void UnRegisterListeners()
    {
        if (!isListenerRegistered && InputHandler.Controller)
            return;

        InputHandler.Controller.RemoveOnPressedListener(KeyCode.UpArrow, () => OnDirectionArrowKeyPressed(Direction.Up), isEscapedUI);
        InputHandler.Controller.RemoveOnPressedListener(KeyCode.DownArrow, () => OnDirectionArrowKeyPressed(Direction.Down), isEscapedUI);
        InputHandler.Controller.RemoveOnPressedListener(KeyCode.LeftArrow, () => OnDirectionArrowKeyPressed(Direction.Left), isEscapedUI);
        InputHandler.Controller.RemoveOnPressedListener(KeyCode.RightArrow, () => OnDirectionArrowKeyPressed(Direction.Right), isEscapedUI);
        InputHandler.Controller.RemoveOnPressedListener(KeyCode.Space, OnSpaceBarKeyPressed, isEscapedUI);
        isListenerRegistered = false;
    }

    public void SetSelected(bool selected)
    {
        isSelected = selected;

        Color newColor = img_outline.color;
        newColor.a = selected ? 1 : 0;
        img_outline.color = newColor;

        if (selected && !isListenerRegistered)
            RegisterListeners();
        else if (!selected && isListenerRegistered)
            UnRegisterListeners();
        else
            Debug.Log($"warning. selected:{selected}, isregistered:{isListenerRegistered}");
    }

    public void SetText(string content)
    {
        txt_content.text = content;
    }

    public void SetOnClickListener(UnityAction callback)
    {
        btn_local.onClick.AddListener(callback);
    }

    private void OnDirectionArrowKeyPressed(Direction direction)
    {
        SetSelected(false);
        KeyBoardButton button = GetButtonWithDirection(direction);
        if (button)
            button.SetSelected(true);
    }

    private KeyBoardButton GetButtonWithDirection(Direction direction)
    {
        switch (direction)
        {
            case Direction.Up:
                return btn_up;

            case Direction.Down:
                return btn_down;

            case Direction.Left:
                return btn_left;

            case Direction.Right:
                return btn_right;
        }

        return null;
    }

    private void OnSpaceBarKeyPressed()
    {
        btn_local.onClick?.Invoke();
    }
}