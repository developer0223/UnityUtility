﻿// Unity
using UnityEngine;
using UnityEngine.SceneManagement;

public class UIManager_TitleScene : UIManager
{
    public KeyBoardButton btn_start;
    public KeyBoardButton btn_howto;
    public KeyBoardButton btn_quit;

    private void Start()
    {
        AddListeners();
    }

    private void AddListeners()
    {
        btn_start.SetOnClickListener(OnStartButtonPressed);
        btn_howto.SetOnClickListener(OnHowToButtonPressed);
        btn_quit.SetOnClickListener(OnQuitButtonClicked);
    }

    private void OnStartButtonPressed()
    {
        SceneManager.LoadScene(SceneName._03_Menu);
    }

    private void OnHowToButtonPressed()
    {
        Debug.Log("HowTo Button Clicked");
    }

    private void OnQuitButtonClicked()
    {
        Application.Quit();
    }
}