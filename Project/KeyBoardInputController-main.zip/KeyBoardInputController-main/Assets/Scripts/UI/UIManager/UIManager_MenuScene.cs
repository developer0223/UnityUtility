﻿// System
using System;
using System.Collections;
using System.Collections.Generic;

// Unity
using UnityEngine;
using UnityEngine.UI;

public class UIManager_MenuScene : UIManager
{
    private void Start()
    {

    }
}
