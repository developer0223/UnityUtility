﻿// System
using System.Collections;

// Unity
using UnityEngine;

public class UIManager_Splash : UIManager
{
    private void Start()
    {
        StartCoroutine(Co_DelayedSceneLoad());
    }

    protected new void OnEnable() { } // [override] do nothing

    protected new void OnDisable() { } // [override] do nothing


    private IEnumerator Co_DelayedSceneLoad()
    {
        yield return new WaitForSeconds(2.5f);
        SceneLoader.LoadScene(SceneName._02_Title);
    }
}