﻿// Unity
using UnityEngine;

public class UIManager : MonoBehaviour
{
    public GameObject pnl_escape;

    protected void OnEnable()
    {
        GameManager.Controller.RegisterUIManager(this);
    }

    protected void OnDisable()
    {
        GameManager.Controller.RegisterUIManager(null);
    }

    public void SetEscapeUIVisible(bool visible)
    {
        if (pnl_escape)
            pnl_escape.SetActive(visible);
    }
}