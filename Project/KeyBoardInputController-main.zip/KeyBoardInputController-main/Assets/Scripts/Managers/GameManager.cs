﻿// System
using System;
using System.Collections;
using System.Collections.Generic;

// Unity
using UnityEngine;
using UnityEngine.UI;

public class GameManager : MonoBehaviour
{
    // public static gamemanager instance
    public static GameManager Controller = null;

    [Header("Escaped State")]
    public bool isEscaped = false;

    [Header("Current UIManager")]
    public UIManager currentUIManager;

    private void Awake()
    {
        Controller = this;
    }

    private void Start()
    {
        InputHandler.Controller.SetOnPressedListener(new KeyBoardAction(KeyCode.Escape, OnEscapeKeyDown, true, false));
        InputHandler.Controller.SetOnPressedListener(new KeyBoardAction(KeyCode.Escape, OnEscapeKeyDown, false, false));
    }

    public void RegisterUIManager(UIManager manager)
    {
        this.currentUIManager = manager;
    }

    private void OnEscapeKeyDown()
    {
        isEscaped = !isEscaped;
        if (currentUIManager)
        {
            currentUIManager.SetEscapeUIVisible(isEscaped);
        }
    }
}