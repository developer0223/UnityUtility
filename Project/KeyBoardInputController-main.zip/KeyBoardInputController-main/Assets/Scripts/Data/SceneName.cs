﻿public class SceneName
{
    public static readonly string _01_Splash = "01.Splash";
    public static readonly string _02_Title = "02.Title";
    public static readonly string _03_Menu = "03.Menu";

    public static readonly string _99_Loading = "99.Loading";
}